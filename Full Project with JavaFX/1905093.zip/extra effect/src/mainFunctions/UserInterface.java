package mainFunctions;

import java.time.format.SignStyle;
import java.util.*;

public class UserInterface {

    private ArrayList<Player> playerList;
    private ArrayList<Club> clubList;
    private ArrayList<Country> countryList;
    private int clubDecided;

    //Utility functions
    public int ErrorHandling(int min, int max){
        int result;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Please enter a valid input");
            result = sc.nextInt();
        }while(result<min || result>max);

        return result;
    }
    public int CheckIfAllDigits(String text){
        boolean flag;
        String s;
        do{
            flag = true;
            Scanner sc = new Scanner(System.in);
            System.out.print(text);
            s = sc.nextLine();
            for (int i = 0; i < s.length(); i++) {
                if(Character.isDigit(s.charAt(i))!=true){
                    flag=false;
                    System.out.println("Enter a valid input");
                    break;
                }
            }
        }while (flag==false);

        return Integer.parseInt(s);
    }
    public double CheckIfDouble(String text){
        boolean flag=false;
        String s;
        Double x = 0.0;

        while(flag==false){
            try {
                System.out.print(text);
                Scanner sc = new Scanner(System.in);
                String str = sc.next();
                Double doub = Double.parseDouble(str);
                flag=true;
                x = doub;
                if(doub<0){
                    flag=false;
                    System.out.println("Input can't be negative");
                }
            }catch (NumberFormatException ex) {
                System.out.println("Given String is not parsable to double,Enter a valid input");
                flag=false;
            }
        }
        return x;
    }
    public int CheckForNumberRepetition(String s){
        Scanner sc = new Scanner(System.in);
        int number;
        int result=0;
        boolean flag;
        do{
            System.out.print("Enter Player Number: ");
            flag=true;
            number = sc.nextInt();
            for (int i = 0; i < playerList.size(); i++) {
                if(s.equalsIgnoreCase(playerList.get(i).getClubs().getClubName())==true){
                    for (int j = 0; j<playerList.size() ; j++) {
                        if(playerList.get(i).getNumber()==number){
                            System.out.println("Player of this number already exist in this club,try again");
                            flag=false;
                            break;
                        }
                    }
                }
            }
        } while(flag==false);

        return number;
    }
    public String CheckNamesForRepetition(){
        int flag;
        String name;
        do{
            flag=1;
            System.out.print("Enter the player name: ");
            Scanner x = new Scanner(System.in);
            name = x.nextLine();

            for (int i = 0; i < playerList.size(); i++) {
                if(name.equalsIgnoreCase(playerList.get(i).getName())==true){
                    flag=0;
                    System.out.println("Player of this name already exits,try again");
                    break;
                }
            }
        }while(flag==0);

        return name;
    }

    //Option 1 functions
    public ArrayList<Player> SearchClubAndCountry(String countryName, String clubName, ArrayList<Player> playerArrayList){
        ArrayList<Player> p= new ArrayList<>();
        int clubFound =1;
        int countryFound=1;
        int found=0;

        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getClubs().getClubName().equalsIgnoreCase(clubName) && playerArrayList.get(i).getCountry().getCountryName().equalsIgnoreCase(countryName)==true){
                p.add(playerArrayList.get(i));
                found =1;
            }
        }
        if(clubName.equalsIgnoreCase("ANY")==true){
            for (int i = 0; i < playerList.size(); i++) {
                if(playerArrayList.get(i).getCountry().getCountryName().equalsIgnoreCase(countryName)==true){
                    p.add(playerArrayList.get(i));
                    found=1;
                }
            }
        }
        if(found==0){
            System.out.println("This player doesn't exist in the database");
        }

        return p;
        //MainMenu(playerList,clubList,countryList);
    }
    public ArrayList<Player> SearchWithPosition(String position, ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();

        int found =0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(position.equalsIgnoreCase(playerArrayList.get(i).getPosition())==true){
                //System.out.println(playerList.get(i).getName());
                p.add(playerArrayList.get(i));
            }
        }

        return p;

        //MainMenu(playerList,clubList,countryList);
    }
    public ArrayList<Player> SearchWithSalaryRange(Double lowerBound, Double upperBound, ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();

        int found = 0 ;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getSalary()> lowerBound && playerArrayList.get(i).getSalary()<upperBound){
                found=1;
                //System.out.println(playerList.get(i).getName()+" : "+ playerList.get(i).getSalary());
                p.add(playerArrayList.get(i));
            }
        }

        if(found==0){
            System.out.println("Player between this salary range doesn't exist");
        }

        return p;

        //MainMenu(playerList,clubList,countryList);

    }
    public int CountryWisePlayerCount(String countryName, ArrayList<Player> playerArrayList){

        int found=0;
        int count=0;
        for(int i=0 ; i< playerArrayList.size();i++){
            if(playerArrayList.get(i).getCountry().getCountryName().equalsIgnoreCase(countryName)==true){
                found=1;
                count++;
            }
        }
        if(found==1){
            System.out.println("PLayer from " +countryName + " : " + count);
            return count;
        }
        else{
            System.out.println("Players from this Country doesn't exist");
            return 0;
        }
        // MainMenu(playerList,clubList,countryList);
    };

    public ArrayList<Player> SearchWithPlayerName(String s, ArrayList<Player> playerArrayList){

        ArrayList<Player> p = new ArrayList<>();
        System.out.println("************");
        System.out.println("Entered =" + s);
        for (int i = 0; i < playerArrayList.size(); i++) {
            System.out.println(playerArrayList.get(i).getName());
        }
        System.out.println("***************");

        int searchSuccessful=0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(s.equalsIgnoreCase(playerArrayList.get(i).getName())==true){
                System.out.println("matched");
                p.add(playerArrayList.get(i));
                searchSuccessful=1;
            }
        }
        if(searchSuccessful==0){//Error Handling
            System.out.println("This Player doesn't exist in the database");
        }

        return p;

    };


    public void ExtraSearchByPosition2() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter position: ");
        String position = sc.nextLine();
        HashMap<String, Double> salary = new HashMap<String, Double>();

        for (int i=0 ; i<clubList.size() ;i++) {;
            int x = 0;
            double totalSalary = 0.0;

            for (int k = 0; k < clubList.get(i).getPlayerList().size(); k++) {
                if (clubList.get(i).getPlayerList().get(k).getPosition().equalsIgnoreCase(position)) {
                    totalSalary += clubList.get(i).getPlayerList().get(k).getSalary();
                    x++;
                }
            }

            double average = totalSalary/x;
            salary.put(clubList.get(i).getClubName(), average);
        }

        //for (int i=0; i<salary.size(); i++) {
        System.out.println(salary);
    }


    //Option 2 functions
    public ArrayList<Player> MaxSalaryInClub(String clubName, ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();

        boolean found= false;
        double maxSalary=0;
        for (int i = 0; i < playerArrayList.size(); i++) {

            if(playerArrayList.get(i).getClubs().getMaxSalary()>maxSalary){
                maxSalary= playerArrayList.get(i).getClubs().getMaxSalary();
                System.out.println(maxSalary);
                for (int j = 0; j < playerArrayList.size(); j++) {
                    if(maxSalary==playerArrayList.get(j).getSalary()){
                        p.add(playerArrayList.get(i));
                    }
                }
                found=true;
                break;
            }
        }

        return p;
//        if(found){
//            System.out.println("The Max Salary of the club is: " + maxSalary);
//        }
//        if(found==false){
//            System.out.println("This club doesn't exist");
//        }
//        MainMenu(playerList,clubList,countryList);
    }

//    public ArrayList<Player> MaxAgeInClub(String clubname, ArrayList<Player> playerArrayList){
//        ArrayList<Player> p = new ArrayList<>();
//
//        System.out.println("GIGAIMPACT");
//        boolean found= false;
//        int maxAge=0;
//        for (int i = 0; i < playerArrayList.size(); i++) {
//
//            System.out.println(playerArrayList.get(i).getClubs().GetMaxAge());
//            if (playerArrayList.get(i).getClubs().GetMaxAge() > maxAge) {
//                maxAge = playerArrayList.get(i).getClubs().GetMaxAge();
//                System.out.println(maxAge);
//            }
//        }
//                for (int j = 0; j < playerArrayList.size(); j++) {
//                    if(maxAge==playerArrayList.get(j).getSalary()){
//                        p.add(playerArrayList.get(j));
//                        break;
//                    }
//                }
//        return p;
//    }

    public ArrayList<Player> ageFind(ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();
        int temp=0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getAge()>temp){
                temp=playerArrayList.get(i).getAge();
            }
        }

        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getAge()==temp){
                p.add(playerArrayList.get(i));
            }
        }
        return p;
    }

    public ArrayList<Player> salaryFind(ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();
        double temp=0.0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getSalary()>temp){
                temp= playerArrayList.get(i).getSalary();
            }
        }

        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getSalary()==temp){
                p.add(playerArrayList.get(i));
            }
        }

        return p;
    }

    public ArrayList<Player> heightFind(ArrayList<Player> playerArrayList){
        ArrayList<Player> p = new ArrayList<>();
        double temp=0.0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getHeight()>temp){
                temp= playerArrayList.get(i).getHeight();
            }
        }

        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getHeight()==temp){
                p.add(playerArrayList.get(i));
            }
        }

        return p;
    }

//    public int MaxAgeInClub(String clubName){
//
//        boolean found= false;
//        int maxAge=0;
//        for (int i = 0; i < clubList.size(); i++) {
//            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
//                clubList.get(i).GetMaxAge();
//                found=true;
//                break;
//            }
//        }
//        if(found==false){
//            System.out.println("This club doesn't exist");
//            return 0;
//        }
//
//        return maxAge;
//        //MainMenu(playerList,clubList,countryList);
//    }
    public ArrayList<Player> MaxHeightInClub(String clubName, ArrayList<Player> playerArrayList){

        ArrayList<Player> temp = new ArrayList<>();
        boolean found= false;
        double maxHeight=0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            if(playerArrayList.get(i).getClubs().findMaxHeight()>maxHeight){
                maxHeight= playerArrayList.get(i).getClubs().findMaxHeight();
                temp.add(playerArrayList.get(i));
            }
        }
        return temp;
        //MainMenu(playerList,clubList,countryList);
    }
    public double YearlySalaryOfClub(String clubName){

        boolean found= false;
        double yearlySalary=0;
        for (int i = 0; i < clubList.size(); i++) {
            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
                clubList.get(i).FindYearlySalary();
                yearlySalary= clubList.get(i).getMaxSalary();

                found=true;
                break;
            }
        }
        if(found){
            return yearlySalary;
        }

        else {
            System.out.println("This club doesn't exist");
            return 0;
        }
        //MainMenu(playerList,clubList,countryList);
    }

    public void Print(ArrayList<Player> p){

        for (int i = 0; i < p.size(); i++) {
            p.get(i).getAllPlayerInfo();
        }
    }

    public void MenuSelect(int x){
        if(x==1){
            System.out.println("(1) By Player Name\n" +
                    "(2) By Club and Country\n" +
                    "(3) By Position\n" +
                    "(4) By Salary Range\n" +
                    "(5) Country-wise player count\n" +
                    "(6) Back to Main Menu");

            Scanner sc1 = new Scanner(System.in);
            int option1 = sc1.nextInt();

            SearchPlayers(option1);


        }

        if(x==2){
            System.out.println("Club Searching Options:\n" +
                    "(1) Player(s) with the maximum salary of a club\n" +
                    "(2) Player(s) with the maximum age of a club\n" +
                    "(3) Player(s) with the maximum height of a club\n" +
                    "(4) Total yearly salary of a club\n" +
                    "(5) Back to Main Menu\n" + "(6)Search By position");

            int option2 = ErrorHandling(1,6);
            SearchClubs(option2);
        }

        if(x==3){
            AddPlayers();
        }

        if(x==4){
            System.out.println("Data has been saved to file");
        }

        if(x==5){
            ExtraOptions();
        }

    }


    public void MainMenu(ArrayList<Player> playerList, ArrayList<Club> clubList, ArrayList<Country> countryList) {

        this.playerList = new ArrayList<>(playerList);
        this.clubList = new ArrayList<>(clubList);
        this.countryList = new ArrayList<>(countryList);


        System.out.println("Main Menu:");
        System.out.println("(1) Search Players");
        System.out.println("(2) Search Clubs");
        System.out.println("(3) Add Player");
        System.out.println("(4) Exit System");
        System.out.println("(5) Extra Options");
    }

    //MenuSelect(option1);
//        if(option1==1){
//            System.out.println("(1) By Player Name\n" +
//                    "(2) By Club and Country\n" +
//                    "(3) By Position\n" +
//                    "(4) By Salary Range\n" +
//                    "(5) Country-wise player count\n" +
//                    "(6) Back to Main Menu");
//
//            int option2 = ErrorHandling(1,6);
//
////            if(option2==1){
////                Scanner sc = new Scanner(System.in);
////                String name = sc.nextLine();
////                int searchSuccessful=0;
////                for (int i = 0; i < playerList.size(); i++) {
////                    if(name.equalsIgnoreCase(playerList.get(i).getName())==true){
////                        playerList.get(i).getAllPlayerInfo();
////                        searchSuccessful=1;
////                    }
////                }
////                if(searchSuccessful==0){//Error Handling
////                    System.out.println("This Player doesn't exist in the database");
////                }
////
////                MainMenu(playerList,clubList,countryList);
////            }
//
//            SearchPlayers(option2);
//        }
//        if(option1==2){
//
//            int option2 = ErrorHandling(1,6);
//            SearchClubs(option2);
//        }
//        if(option1==3){
//            AddPlayers();
//        }
//        if(option1==4) {
//            System.out.println("Data has been saved to file");
//        }
//        if(option1==5){
//            ExtraOptions();
//            //ExtraSearch(playerList,clubList);
//        }

    public void SearchPlayers(int option2){
        ArrayList a;

        if(option2==1){
            Scanner sc = new Scanner(System.in);
            String name = sc.nextLine();

            a = SearchWithPlayerName(name,playerList);
            Print(a);
        }

        if(option2==2){
            Scanner sc1 = new Scanner(System.in);
            Scanner sc2 = new Scanner(System.in);
            System.out.print("Enter Country Name: ");
            String countryName = sc2.nextLine();
            System.out.print("Enter Club Name: ");
            String clubName = sc1.nextLine();

            a= SearchClubAndCountry(countryName, clubName,playerList);
            Print(a);
        }
        if(option2==3){
            System.out.print("Enter a valid input: ");
            Scanner sc = new Scanner(System.in);
            String position = sc.nextLine();

            a= SearchWithPosition(position,playerList);
            Print(a);
        }
        if(option2==4){
            Scanner sc1 = new Scanner(System.in);
            System.out.print("Enter the Salary lower bound: ");
            Double lowerBound = sc1.nextDouble();
            System.out.print("Enter the Salary Upper Bound: ");
            Double upperBound = sc1.nextDouble();

            a=SearchWithSalaryRange(lowerBound,upperBound,playerList);
            Print(a);
        }
        if(option2==5){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a country name: ");
            String countryName = sc.nextLine();

            //System.out.println(CountryWisePlayerCount(countryName)); ;
        }
        if(option2==6){
            MainMenu(playerList,clubList,countryList);
        }
    }
    public void SearchClubs(int option2){


        if(option2==1){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a club name: ");
            String clubName = sc.nextLine() ;

            //MaxSalaryInClub(clubName);
        }
        if(option2==2){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a club name: ");
            String clubName = sc.nextLine() ;

            //MaxAgeInClub(clubName);
            System.out.println();
        }
        if(option2==3){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a club name: ");
            String clubName = sc.nextLine() ;

            //MaxHeightInClub(clubName);
            System.out.println();
        }
        if(option2==4){
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a club name: ");
            String clubName = sc.nextLine() ;

            YearlySalaryOfClub(clubName);
        }
        if(option2==5){
            MainMenu(playerList,clubList,countryList);
        }
        if(option2==6){
            ExtraSearchByPosition2();
        }
    }
    public void AddPlayers(){

        Player p = new Player();
        int flag;
        Scanner sc = new Scanner(System.in);

        //Name
        String name = CheckNamesForRepetition();
        p.setName(name);

        //Country
        System.out.print("Enter Country: ");
        String country = sc.nextLine();
        p.addToCountry(countryList,country);

        //Age
        int age = CheckIfAllDigits("Enter Age: ");
        p.setAge(age);

        //Height
        double h = CheckIfDouble("Enter Height: ");
        p.setHeight(h);

        //Club
        String club;
        do{
            System.out.print("Enter Club: ");
            club = sc.nextLine();
            p.addToClub(clubList, club);
        }while(p.getClubDecided()==0);

        //Position
        System.out.print("Enter Position: ");
        String position = sc.nextLine();
        p.setPosition(position);

        //Number
        int num =  CheckForNumberRepetition(club);
        p.setNumber(num);

        //Weekly Salary
        double salary = CheckIfDouble("Enter Salary: ");
        p.setSalary(salary);

        playerList.add(p);

        MainMenu(playerList,clubList,countryList);
    }
    public void ExtraOptions(){
        System.out.println("View all player info in current database");
        System.out.println("(1) Yes");
        System.out.println("(2) No (Return to Main Menu)");

        int x = ErrorHandling(1,2);
        if(x==1){
            for (int i = 0; i < playerList.size(); i++) {
                playerList.get(i).getAllPlayerInfo();
            }
            MainMenu(playerList,clubList,countryList);
        }
        else {
            MainMenu(playerList,clubList,countryList);
        }
    }

    public ArrayList<Player> ReturnList(){
        return playerList;
    }

}

