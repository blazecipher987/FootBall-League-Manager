package mainFunctions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;


public class FileHandling {
    private static final String INPUT_FILE_NAME = "original.txt";
    private static final String OUTPUT_FILE_NAME = "original.txt";

    public ArrayList<Player> readFromFile(ArrayList<Club> clubList, ArrayList<Country> countryList) throws Exception {
        ArrayList<Player> playerList = new ArrayList();
        //List<Club> clubList = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        // var br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        while (true) {
            String line = br.readLine();
            if (line == null) break;
            String[] tokens = line.split(",");

//            Player s = new Player();
//            s.setName(tokens[0]);
//            s.addToCountry(countryList, tokens[1]);
//            s.setAge(Integer.parseInt(tokens[2]));
//            s.setHeight(Double.parseDouble(tokens[3]));
//            s.addToClub(clubList, tokens[4]);
//            s.setPosition(tokens[5]);
//            s.setNumber(Integer.parseInt(tokens[6]));
//            s.setSalary(Double.parseDouble(tokens[7]));
//            playerList.add(s);

            Player s1 = new Player(tokens[0],tokens[1],Integer.parseInt(tokens[2]),Double.parseDouble(tokens[3]),tokens[4],tokens[5],Integer.parseInt(tokens[6]),Double.parseDouble(tokens[7]),clubList,countryList);
            playerList.add(s1);

        }
        br.close();
        return playerList;
    }

    public void writeToFile(ArrayList<Player> playerArrayList) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        //System.out.println("Inside write function");
//            for(int j=0 ; j<playerArrayList.size() ;j++){
//                playerArrayList.get(j).getAllPlayerInfo();
//            };
        // var bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));
        for (Player s : playerArrayList) {

            bw.write(s.getName()+ "," + s.getCountry().getCountryName() + "," + s.getAge() + "," + s.getHeight()+ ","+ s.getClubs().getClubName()+","+ s.getPosition() +","+s.getNumber() +"," + s.getSalary());
            bw.write("\n");
        }
        bw.close();
    }

}

