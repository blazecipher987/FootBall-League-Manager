package mainFunctions;

import javafx.beans.property.SimpleStringProperty;
import sample.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import sample.personViewController;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Player implements Serializable {

    protected String name;
    protected int age;
    protected double height;
    protected Club clubs;
    protected String position;
    protected int number;
    protected double salary;
    protected Country country;
    protected int clubDecided;
    protected double price;

    protected Parent root;
    protected Stage stage;
    protected Scene scene;
    //private Button button;
    protected SimpleStringProperty fname;
    protected SimpleStringProperty fclub;
    protected SimpleStringProperty fage;
    protected SimpleStringProperty fcountry;
    protected SimpleStringProperty fheight;
    protected SimpleStringProperty fsalary;
    protected SimpleStringProperty fposition;
    protected SimpleStringProperty fnumber;
    protected SimpleStringProperty fprice;



    public Player(){


        clubDecided= 0;


        //this.button = new Button("Click");
//        button.setOnAction( e -> {
//                    //System.out.println(getFirstName() + " " + getLastName() + " " + getEmail());
//
//                    FXMLLoader loader = new FXMLLoader(getClass().getResource("personalView.fxml"));
//                    try {
//                        root = loader.load();
//                        personViewController personViewController = loader.getController();
//                        System.out.println(country.getCountryName() + clubs.getClubName());
//                        personViewController.showData(name,country.getCountryName(),age,height,clubs.getClubName(),position,salary,price);
//
//                        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
//                        scene = new Scene(root);
//                        stage.setScene(scene);
//                        stage.show();
//                    } catch (IOException ioException) {
//                        ioException.printStackTrace();
//                    }
//
//                }
//        );
    }

    Player(String name, String country, int age, double height, String clubs, String position, int number, double salary, ArrayList<Club> clubArrayList, ArrayList<Country> countryArrayList){

        this.name = name;
       // this.country.s = country;
        this.age = age;
        this.height = height;
        //this.clubs = clubs;
        this.position = position;
        this.number = number;
        this.salary = salary;

        addToClub(clubArrayList,clubs);
        addToCountry(countryArrayList,country);

//        this.fname = new SimpleStringProperty(name);
//        this.fcountry = new SimpleStringProperty(country);
//        this.fage = new SimpleStringProperty(Integer.toString(age));
//        this.fheight = new SimpleStringProperty(Double.toString(height));
//        this.fclub = new SimpleStringProperty(clubs);
//        this.fposition = new SimpleStringProperty(position);
//        this.fnumber = new SimpleStringProperty(Integer.toString(number));
//        this.fsalary = new SimpleStringProperty(Double.toString(salary));

       // this.button = new Button("Click");

//        button.setOnAction( e -> {
//            //System.out.println(getFirstName() + " " + getLastName() + " " + getEmail());
//
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/personalView.fxml"));
//            try {
//                root = loader.load();
//                personViewController personViewController = loader.getController();
//                //System.out.println(country.getCountryName() + clubs.getClubName());
//                personViewController.showData(name,country,age,height,clubs,position,salary,price);
//
//                stage = (Stage)((Node)e.getSource()).getScene().getWindow();
//                scene = new Scene(root);
//                stage.setScene(scene);
//                stage.show();
//            } catch (IOException ioException) {
//                ioException.printStackTrace();
//            }
//
//        }
//        );

    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public Club getClubs() {
        return clubs;
    }

    public void setClubs(Club clubs) {
        this.clubs = clubs;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getClubDecided() {
        return clubDecided;
    }

//    public Button getButton() {
//        return button;
//    }
//
//    public void setButton(Button button) {
//        this.button = button;
//    }

    public void setClubDecided(int clubDecided) {
        this.clubDecided = clubDecided;
    }
    public boolean notAddedToClub(){
        return false;
    }

    public void addToClub(ArrayList<Club> c, String s){

        // System.out.println("Executing adding to club, string " + s);
        int notRepeat = 1;
        int index = 0;

        for (int i = 0; i < c.size(); i++) {
            //System.out.println("Gif");
            if(c.get(i).getClubName().equals(s) == true){
                //System.out.println("Got a match");
                notRepeat = 0;
                index =i;
                break;
            }
        }

        if(notRepeat==0){
            if(c.get(index).getCurrentPlayerCount() <7){
                clubDecided=1;
                //System.out.println("same as club " + index);
                c.get(index).addPlayer(this);
                c.get(index).setCurrentPlayerCount(c.get(index).getCurrentPlayerCount()+1);
                this.setClubs(c.get(index));
            }
            else{
                //System.out.println("Current Club is already full,select another club");
                clubDecided=0;
            }
        }

        else{
            clubDecided=1;
            //System.out.println("Adding to new club");
            Club x = new Club();
            x.setClubName(s);
            x.setCurrentPlayerCount(x.getCurrentPlayerCount()+ 1);
            //System.out.println(x.getCurrentPlayerCount());
            c.add(x);
            c.get(c.size()-1).addPlayer(this);

            for (int i = 0; i < c.size(); i++) {
                if(s.equalsIgnoreCase(c.get(i).getClubName())==true){
                    this.setClubs(c.get(i));
                    break;
                }
            }

        }

    }
    public void addToCountry(ArrayList<Country> c , String s){
        int notRepeat = 1;
        int index=0;
        //System.out.println();

        //System.out.println("Current country: " + s);
        for (int i = 0; i < c.size(); i++) {
            if(c.get(i).getCountryName().equals(s) == true){
                //System.out.println("Got a match");
                notRepeat = 0;
                index =i;
                break;
            }
        }

        if(notRepeat==0){
            //System.out.println("same as Country " + c.get(index).getCountryName());
            c.get(index).addPlayerToCountry(this);
            c.get(index).setCountryPlayerCount(c.get(index).getCountryPlayerCount()+1);
            this.setCountry(c.get(index));


        }
        else{
            //System.out.println("First Country for the entry: " + s);
            Country x = new Country();
            x.setCountryName(s);
            x.setCountryPlayerCount(x.getCountryPlayerCount()+1);
            //System.out.println(x.getCountryPlayerCount());
            c.add(x);

            c.get(c.size()-1).addPlayerToCountry(this);
            for (int i = 0; i < c.size(); i++) {
                if(s.equalsIgnoreCase(c.get(i).getCountryName())==true){
                    this.setCountry(c.get(i));
                    break;
                }
            }

        }
    }
    public void getAllPlayerInfo(){
        System.out.println("Player Name: "+ getName());
        System.out.println("Player country: "+ getCountry().getCountryName());
        System.out.println("Player age: " + getAge());
        System.out.println("Player Height: "+ getHeight());
        System.out.println("Player club: " + this.getClubs().getClubName());
        System.out.println("Player position: " + getPosition());
        System.out.println("Player number: "+ getNumber());
        System.out.println("Player Salary: "+getSalary());
        System.out.println();

    }



}

