package mainFunctions;

import client.LoginController;
import client.ReadThread;
import javafx.scene.control.Alert;
import sample.*;
import optionSelect.*;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import util.NetworkUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main extends Application {
    private static ArrayList<Player> playerList;
    private static ArrayList<Club> clubList;
    private static ArrayList<Country> countryList;
    private static Stage stage;
    //public static ObservableList<Person> x;
    private static ObservableList<Player> x;

    private static ArrayList<Player> sellList;
    private static NetworkUtil networkUtil;

    public static ArrayList<Player> getSellList() {
        return sellList;
    }

    public static void setSellList(ArrayList<Player> sellList) {
        Main.sellList = sellList;
    }

    public static ArrayList<Player> forHome = new ArrayList<>();
    public static boolean status = false;


    public static void main(String[] args) throws Exception {

        clubList = new ArrayList<>();
        countryList = new ArrayList<>();
        FileHandling f = new FileHandling();
        playerList = f.readFromFile(clubList, countryList);
        sellList = new ArrayList<>();


       // p = new Person();




        //Testing
//        for (int i = 0; i < clubList.size(); i++) {
//           //clubList.get(i).printAllClubInfo();
//            //clubList.get(i).findMaxSalary();
//            //clubList.get(i).findMaxAge();
//            //clubList.get(i).findMaxHeight();
//        };
        System.out.println();


        UserInterface u = new UserInterface();
        u.MainMenu(playerList,clubList,countryList);
        launch(args);

        Scanner sc1 = new Scanner(System.in);
        int option1 = sc1.nextInt();
        u.MenuSelect(option1);

        playerList = u.ReturnList();

        f.writeToFile(playerList);


    }



    public void showLoginPage() throws Exception {
        // XML Loading using FXMLLoader
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/client/login.fxml"));
        Parent root = loader.load();

        // Loading the controller
        LoginController controller = loader.getController();
        controller.setMain(this);
        //TableViewController.setMain(this);

        // Set the primary stage
        stage.setTitle("Login");
        stage.setScene(new Scene(root, 850, 500));
        stage.show();

        //showHomePage(forHome,networkUtil);
    }

    public void showHomePage(String username, ArrayList<Player> temp, NetworkUtil networkUtil) throws Exception {
        personViewController.setMain(this);
        TableViewController.setMain(this);
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/optionSelect/menuOptions.fxml"));
        Parent root = loader.load();
        menuOptionController menuOptionController = loader.getController();
        menuOptionController.setpp(temp,stage);
        menuOptionController.setNetworkUtil(networkUtil);
        stage.setScene(new Scene(root, 850, 500));
        stage.show();
    }

    public void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect Credentials");
        alert.setHeaderText("Incorrect Credentials");
        alert.setContentText("The username and password you provided is not correct.");
        alert.showAndWait();
    }

    private void connectToServer() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        networkUtil = new NetworkUtil(serverAddress, serverPort);
        new ReadThread(this);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        connectToServer();
        showLoginPage();
    }

    public Stage getStage() {
        return stage;
    }
    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }
}

