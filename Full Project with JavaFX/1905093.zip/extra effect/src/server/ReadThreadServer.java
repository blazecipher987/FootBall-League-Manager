package server;

import javafx.application.Platform;
import mainFunctions.Player;
import mainFunctions.UserInterface;
import util.LoginDTO;
import util.NetworkUtil;
import sample.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final NetworkUtil networkUtil;
    public HashMap<String, String> userMap;
    public ArrayList<Player> playerArrayList;
    private String userName;
    private String password;
    public static ArrayList<Player> sellList1;
    private deliveryObject deliveryObject = new deliveryObject();


    public ReadThreadServer(HashMap<String, String> map, NetworkUtil networkUtil, ArrayList<Player> playerArrayList, ArrayList<Player> sellList) {
        this.userMap = map;
        this.networkUtil = networkUtil;
        this.thr = new Thread(this);
        this.playerArrayList = playerArrayList;
        this.sellList1 = sellList;

        thr.start();
    }


    public void run() {
        try {

            while (true) {
                System.out.println("At the top");
                Object o = networkUtil.read();
                System.out.println("At the 2nd top");
                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        System.out.println(loginDTO.getUserName());
                        System.out.println(loginDTO.getPassword());

                        userName = userMap.get(loginDTO.getUserName());
                        password = userMap.get(loginDTO.getPassword());
                        System.out.println(userName);
                        System.out.println("pass " + password);


                        ArrayList<Player> temp = new ArrayList<>();
                        for (int i = 0; i < playerArrayList.size(); i++) {
                            if(userName.equalsIgnoreCase(playerArrayList.get(i).getClubs().getClubName())){
                                temp.add(playerArrayList.get(i));
                            }
                        }

                        loginDTO.setStatus(loginDTO.getPassword().equalsIgnoreCase(password));
                        loginDTO.setPlayerArrayList(temp);
                        networkUtil.write(loginDTO);

                    }
                    if(o instanceof ArrayList){
                        System.out.println("done 1");
                        System.out.println(Server.sellList.size());

                        Server.addToSellList((ArrayList<Player>) o);
                        Thread.sleep(100);
                        //networkUtil.write(Server.sellList);
                        System.out.println(Server.sellList.size());
                        System.out.println("Done 2");
                    }
                    if(o instanceof deliveryObject){
                        //Server.addToSellList(((deliveryObject) o).getSellList());
                        //Server.setSellList((ArrayList<Player>) ((deliveryObject) o).getSellList());
                        Server.addToSellList(((deliveryObject) o).getSellList());
                        Server.playerList = ((deliveryObject) o).getPlayerArrayList();
                    }
                    if(o instanceof soldObject){
                        Server.setSellList(((soldObject) o).getSellList());
                    }
                    if(o instanceof String){
                        System.out.println(Server.sellList.size());
                        deliveryObject.setSellList(Server.sellList);
                        deliveryObject.setPlayerArrayList(Server.playerList);
                        networkUtil.write(deliveryObject);
                        //networkUtil.write(Server.sellList);
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                networkUtil.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}



