package server;

import mainFunctions.Club;
import mainFunctions.Country;
import mainFunctions.FileHandling;
import mainFunctions.Player;
import util.NetworkUtil;

import java.io.IOException;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class Server implements Serializable {
    public static ArrayList<Player> playerList = new ArrayList<>();
    private static ArrayList<Club> clubList;
    private static ArrayList<Country> countryList;
    public static ArrayList<Player> sellList = new ArrayList<>();
    public static ArrayList<Player> p;

    public static ArrayList<Player> getPlayerList() {
        return playerList;
    }



    public static void setPlayerList(ArrayList<Player> playerList) {
        Server.playerList = playerList;
    }

    public static void tem(){
        for (int i = 0; i < sellList.size(); i++) {
            p.add(sellList.get(i));
        }
    }

    public static ArrayList<Player> retu(){
        return p;
    }

    public static ArrayList<Player> getSellList() {
        return sellList;
    }

    public static void setSellList(ArrayList<Player> sellList) {
        Server.sellList = sellList;
    }

    private ServerSocket serverSocket;
    public HashMap<String, String> userMap;

    public static void addToSellList(ArrayList<Player> p){
        sellList.addAll(p);
    }

    Server() {
        userMap = new HashMap<>();
        userMap.put("Liverpool", "Liverpool");
        userMap.put("Arsenal", "Arsenal");
        userMap.put("Manchester United", "Manchester United");
        userMap.put("Manchester City", "Manchester City");
        userMap.put("Chelsea", "Chelsea");

        try {
            serverSocket = new ServerSocket(33333);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void serve(Socket clientSocket) throws IOException {
        NetworkUtil networkUtil = new NetworkUtil(clientSocket);
        new ReadThreadServer(userMap, networkUtil,playerList,sellList);
    }

    public static void main(String[] args) throws Exception {
        clubList = new ArrayList<>();
        countryList = new ArrayList<>();
         FileHandling f = new FileHandling();
         playerList = f.readFromFile(clubList, countryList);
         setPlayerList(playerList);
         //sellList = new ArrayList<>();

        System.out.println("ONCEEEeeeeeeeeeeEEEE");


        new Server();
    }
}
