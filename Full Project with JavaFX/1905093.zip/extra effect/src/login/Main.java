//package login;
//import mainFunctions.*;
//import optionSelect.*;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import sample.*;
//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.scene.control.Alert;
//import javafx.stage.Stage;
//
//import java.util.List;
//
//public class Main extends Application {
//
//    private static Stage stage;
//
////    public ObservableList<Person> people = FXCollections.observableArrayList(
////            new Person("Jacob", "Smith", "jacob.smith@example.com"),
////            new Person("Isabella", "Johnson", "isabella.johnson@example.com"),
////            new Person("Ethan", "Williams", "ethan.williams@example.com"),
////            new Person("Emma", "Jones", "emma.jones@example.com"),
////            new Person("Michael", "Brown", "michael.brown@example.com")
////    );
//    public static ObservableList<Person> x;
//    public Stage getStage() {
//        return stage;
//    }
//
//
//    @Override
//    public void start(Stage primaryStage) throws Exception {
//        stage = primaryStage;
//        showLoginPage();
//    }
//
//
//    public void showLoginPage() throws Exception {
//        // XML Loading using FXMLLoader
//        FXMLLoader loader = new FXMLLoader();
//        loader.setLocation(getClass().getResource("login.fxml"));
//        Parent root = loader.load();
//
//        // Loading the controller
//        LoginController controller = loader.getController();
//        controller.setMain(this);
//
//        // Set the primary stage
//        stage.setTitle("Login");
//        stage.setScene(new Scene(root, 400, 250));
//        stage.show();
//    }
//
//    public void showHomePage(String userName) throws Exception {
//
////        FXMLLoader loader = new FXMLLoader();
////        loader.setLocation(getClass().getResource("home.fxml"));
////        Parent root = loader.load();
////
////        // Loading the controller
////        HomeController controller = loader.getController();
////        controller.init(userName);
////        controller.setMain(this);
////
////        // Set the primary stage
////        stage.setTitle("Home");
////        stage.setScene(new Scene(root, 400, 300));
////        stage.show();
//
//        /*
//        FXMLLoader loader = new FXMLLoader();
//        loader.setLocation(getClass().getResource("/sample/tableview.fxml"));
//        Parent root = loader.load();
//        TableViewController controller = loader.getController();
//        controller.load(people);
//        //primaryStage.setTitle("Table View");
//        stage.setScene(new Scene(root, 500, 300));
//        stage.show(); */
//        FXMLLoader loader = new FXMLLoader();
//        loader.setLocation(getClass().getResource("/optionSelect/menuOptions.fxml"));
//        Parent root = loader.load();
//        menuOptionController menuOptionController = loader.getController();
//        menuOptionController.setpp(x,stage);
//        //primaryStage.setTitle("Table View");
//        stage.setScene(new Scene(root, 500, 300));
//        stage.show();
//
//
//
//    }
//
//    public void showAlert() {
//        Alert alert = new Alert(Alert.AlertType.ERROR);
//        alert.setTitle("Incorrect Credentials");
//        alert.setHeaderText("Incorrect Credentials");
//        alert.setContentText("The username and password you provided is not correct.");
//        alert.showAndWait();
//    }
//
//    public static void main(String[] args) {
//        List<Person> people = FXCollections.observableArrayList(
//                new Person("Jacob", "Smith", "jacob.smith@example.com"),
//                new Person("Isabella", "Johnson", "isabella.johnson@example.com"),
//                new Person("Ethan", "Williams", "ethan.williams@example.com"),
//                new Person("Emma", "Jones", "emma.jones@example.com"),
//                new Person("Michael", "Brown", "michael.brown@example.com")
//        );
//
//        x= FXCollections.observableList(people);
//
//        // This will launch the JavaFX application
//        launch(args);
//    }
//}
