package login;
import mainFunctions.*;
import mainFunctions.Main;
import sample.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class LoginController {

    private mainFunctions.Main main;

    @FXML
    private TextField userText;

    @FXML
    private PasswordField passwordText;

    @FXML
    private Button resetButton;

    @FXML
    private Button loginButton;

    @FXML
    void loginAction(ActionEvent event) {
        String userName = userText.getText();
        String password = passwordText.getText();


        if (password.equals("123")) {
            try {
                //main.showHomePage(userName);
            } catch (Exception e) {
                System.out.println(e);
            }
        } else {
            main.showAlert();
        }
    }

    @FXML
    void resetAction(ActionEvent event) {
        userText.setText(null);
        passwordText.setText(null);
    }

    public void setMain(Main main) {
        this.main = main;
    }

}
