package sample;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import mainFunctions.*;
import server.Server;
import util.NetworkUtil;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TableViewController {

    @FXML
    private TableView tableView;
    @FXML
    private TextField textField;
    @FXML
    private Button button, refresh,button2,buy;
    @FXML
    private ImageView clubImage;

    static Main main;

    public static Main getMain() {
        return main;
    }

    public static void setMain(Main main) {
        TableViewController.main = main;
    }

    public static ObservableList<Player> getData() {
        return data;
    }

    public static void setData(ObservableList<Player> data) {
        TableViewController.data = data;
    }

    public static ArrayList<Player> getPlayerArrayList() {
        return playerArrayList;
    }

    public static void setPlayerArrayList(ArrayList<Player> playerArrayList) {
        TableViewController.playerArrayList = playerArrayList;
    }

    public static int getChoice() {
        return choice;
    }

    public static void setChoice(int choice) {
        TableViewController.choice = choice;
    }

    //static ObservableList<Person> data;
    static ObservableList<Player> data;
    static ArrayList<Player> playerArrayList; //ALL OUR DATA COMES HERE FIRST
    private UserInterface u = new UserInterface();
    private static int choice;
    ArrayList<PlayerForTable> playerForTables = new ArrayList<>();
    private NetworkUtil networkUtil;
    public static ArrayList<Player> selling = new ArrayList<>();

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    private boolean init = true;

    private void initializeColumns() {
        TableColumn<PlayerForTable, String> nameCol = new TableColumn<>("Name");
        nameCol.setMinWidth(40);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<PlayerForTable, String> countryCol = new TableColumn<>("Country");
        countryCol.setMinWidth(40);
        countryCol.setCellValueFactory(new PropertyValueFactory<>("countrys"));

        TableColumn<PlayerForTable, String> ageCol = new TableColumn<>("Age");
        ageCol.setMinWidth(40);
        ageCol.setCellValueFactory(new PropertyValueFactory<>("age"));

        TableColumn<PlayerForTable, String> heightCol = new TableColumn<>("Height");
        heightCol.setMinWidth(40);
        heightCol.setCellValueFactory(new PropertyValueFactory<>("height"));

        TableColumn<PlayerForTable, String> clubCol = new TableColumn<>("Club");
        clubCol.setMinWidth(40);
        clubCol.setCellValueFactory(new PropertyValueFactory<>("clebs"));

        TableColumn<PlayerForTable, String> posCol = new TableColumn<>("Position");
        posCol.setMinWidth(40);
        posCol.setCellValueFactory(new PropertyValueFactory<>("position"));

        TableColumn<PlayerForTable, String> numberCol = new TableColumn<>("Number");
        numberCol.setMinWidth(40);
        numberCol.setCellValueFactory(new PropertyValueFactory<>("number"));

        TableColumn<PlayerForTable, String> salaryCol = new TableColumn<>("Salary");
        salaryCol.setMinWidth(40);
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));

        TableColumn<PlayerForTable, String> buttonCol = new TableColumn<>("Button");
        buttonCol.setMinWidth(40);
        buttonCol.setCellValueFactory(new PropertyValueFactory<>("button"));

        tableView.getColumns().addAll(nameCol,countryCol,ageCol,heightCol,clubCol,posCol,numberCol,salaryCol,buttonCol);
    }

    public void refresh(ObservableList<Player> p){

    }

    public void load(ObservableList<PlayerForTable> p) {
        if (init) {
            initializeColumns();
            init = false;
        }

        //Image image = new Image(String.valueOf(Main.class.getResource( "/Footballer's Image/"+playerArrayList.get(0).getClubs().getClubName() +".jpg")));
        Image image = new Image(String.valueOf(Main.class.getResource( "/sample/" + playerArrayList.get(0).getClubs().getClubName().toLowerCase() +".jpg")));

        System.out.println("YO 2");
        clubImage.setImage(image);

        tableView.setEditable(true);
        tableView.setItems(p);
    }

    @FXML
    void buttonAction(ActionEvent event) throws IOException, ClassNotFoundException, InterruptedException {

        if(event.getSource()==button && choice==1) {
            String str = textField.getText();

            ArrayList<Player> temp = u.SearchWithPlayerName(str, playerArrayList);
            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if(event.getSource()==button && choice==2){
            String str = textField.getText();
            System.out.println("I am listenng");
            ArrayList<Player> temp = u.SearchClubAndCountry(str,playerArrayList.get(0).getClubs().getClubName(),playerArrayList);

            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if (event.getSource()==button && choice==20){

            //ArrayList<Player> temp = (ArrayList<Player>) main.getNetworkUtil().read();
            //ArrayList<Player> temp = personViewController.seller;
            String e = new String("Yo");
            main.getNetworkUtil().write(e);
            Thread.sleep(1000);
            //ArrayList<Player> temp = (ArrayList<Player>) main.getNetworkUtil().read();
            ArrayList<Player> temp = selling;
            System.out.println("After read");
            System.out.println(temp.size());


            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            tableView.refresh();
            System.out.println("You should print a table");

        }
        if(event.getSource()==buy && choice==20){
            System.out.println("Yesp");
            ObservableList<Player> p = tableView.getSelectionModel().getSelectedItems();

        }

        if(event.getSource()==button && choice==3){
            String str = textField.getText();

            ArrayList<Player> temp = u.SearchWithPosition(str, playerArrayList);
            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if(event.getSource()==button && choice==4){
            String str = textField.getText();
            String[] token = str.split("-");
            Double d1 = Double.parseDouble(token[0]);
            Double d2 = Double.parseDouble(token[1]);
            Double max =0.0, min =0.0;
            if(d1>d2){
                max=d1;
                min=d2;
            }
            else {
                max=d2;
                min=d1;
            }

            //System.out.println(max+min);
            ArrayList<Player> temp = u.SearchWithSalaryRange(min,max,playerArrayList);

            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if(event.getSource()==button && choice==5){
            System.out.println("Entered");
            //String str = textField.getText();
            //String[] token = str.split("-");
            textField.disableProperty();
            ArrayList<Player> temp = u.salaryFind(playerArrayList);

            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if(event.getSource()==button && choice==6){
            System.out.println("Entered");
            //String str = textField.getText();
            //String[] token = str.split("-");
            textField.disableProperty();
            ArrayList<Player> temp = u.ageFind(playerArrayList);

            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }
        if(event.getSource()==button && choice==7){
            System.out.println("Entered");
            //String str = textField.getText();
            //String[] token = str.split("-");
            textField.disableProperty();
            ArrayList<Player> temp = u.heightFind(playerArrayList);

            playerForTables.clear();
            for (int i = 0; i < temp.size(); i++) {
                playerArrayList.get(i).setName(temp.get(i).getName());
            }

            for (int i = 0; i < temp.size(); i++) {

                String name = temp.get(i).getName();
                String country = temp.get(i).getCountry().getCountryName();
                int age = temp.get(i).getAge();
                double height = temp.get(i).getHeight();
                String clubs = temp.get(i).getClubs().getClubName();
                String position = temp.get(i).getPosition();
                int number = temp.get(i).getNumber();
                double salary = temp.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
            //data.get(0).setFirstName("JacobN ");
            //data.get(0).setLastName("SmithN");
            tableView.refresh();
        }

        if(event.getSource()==refresh){
            playerForTables.clear();

            for (int i = 0; i < playerArrayList.size(); i++) {

                String name = playerArrayList.get(i).getName();
                String country = playerArrayList.get(i).getCountry().getCountryName();
                int age = playerArrayList.get(i).getAge();
                double height = playerArrayList.get(i).getHeight();
                String clubs = playerArrayList.get(i).getClubs().getClubName();
                String position = playerArrayList.get(i).getPosition();
                int number = playerArrayList.get(i).getNumber();
                double salary = playerArrayList.get(i).getSalary();

                System.out.println(name+country+age+clubs+position+number+salary);

                PlayerForTable playerForTable = new PlayerForTable(name,country,age,height,clubs,position,number,salary);

                playerForTables.add(playerForTable);
            }


            for (int i = 0; i < playerForTables.size(); i++) {
                System.out.println(playerForTables.get(i).getName());
            }

            ObservableList<PlayerForTable> x = FXCollections.observableArrayList(playerForTables);
            load(x);
        }
    }
}
