package sample;
import mainFunctions.*;
import login.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import mainFunctions.Main;
import server.Server;


import java.io.IOException;
import java.util.ArrayList;


public class personViewController {

    static Main main;

    public static Main getMain() {
        return main;
    }

    public static void setMain(Main main) {
        personViewController.main = main;
    }

    @FXML
    Label fName,email;
    @FXML
    ImageView dp;
    @FXML
    Button back,sellPlayer,buy;
    @FXML
    Label name, country,age,height,club,position,salary,price;

    private Stage stage;
    private Scene scene;
    private Parent root;
    private int index;
    static ArrayList<Player> seller = new ArrayList<>();
    static ArrayList<Player> sellList = new ArrayList<>();
    private deliveryObject deliveryObject = new deliveryObject();
    private soldObject soldObject = new soldObject();

//    void showData(String name, String emaill, String img){
//
//        fName.setText(name);
//        email.setText(emaill);
//        System.out.println(name + emaill);
//        Image image = new Image(String.valueOf(Main.class.getResource( "/sample/" + name + ".jpg")));
//        System.out.println("YO 2");
//        dp.setImage(image);
//    }

    public void showData(String name1, String country1, int age1, double height1, String club1, String position1, double salary1, double price1){

        name.setText(name1);
        country.setText("Country: " + country1);
        age.setText("Age: "+ String.valueOf(age1));
        height.setText("Height: "+ String.valueOf(height1));
        club.setText(club1);
        position.setText("Position: " + position1);
        salary.setText("Salary: " + String.valueOf(salary1));
        price.setText("Price: " + "50,000$");

        //Image image = new Image(String.valueOf(Main.class.getResource( "/sample/Jacob.jpg")));
        Image image = new Image(String.valueOf(Main.class.getResource( "/Footballer's Image/"+ name1 +".jpg")));
        System.out.println("YO 2");
        dp.setImage(image);


    }

    public void returnn(ActionEvent event) throws IOException, ClassNotFoundException, InterruptedException {

        if(event.getSource()==back){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/optionSelect/menuOptions.fxml"));
            try {
                root = loader.load();
                //Person person = loader.getController();
                //personViewController.showData(fName,emaill,fName);

                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }

        if(event.getSource()==buy){
            System.out.println("Howdy,so you wanna buy?");
            System.out.println(TableViewController.selling.size());

            for (int i = 0; i < TableViewController.selling.size(); i++) {
                if(name.getText().equalsIgnoreCase(TableViewController.selling.get(i).getName())){
                    TableViewController.selling.get(i).getClubs().setClubName(club.getText());
                    TableViewController.playerArrayList.add(TableViewController.selling.get(i));
                    TableViewController.selling.remove(i);

//                    deliveryObject.setSellList(TableViewController.selling);
//                    main.getNetworkUtil().write(deliveryObject);
//                    seller.clear();

                    soldObject.setSellList(TableViewController.selling);
                    main.getNetworkUtil().write(soldObject);

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/optionSelect/menuOptions.fxml"));
                    try {
                        root = loader.load();
                        //Person person = loader.getController();
                        //personViewController.showData(fName,emaill,fName);

                        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }

                }
            }
        }

        if(event.getSource()==sellPlayer){
            System.out.println(name.getText());
            System.out.println("We are getting executed right??");
            System.out.println(TableViewController.playerArrayList.size());

            for (int i = 0; i < TableViewController.playerArrayList.size(); i++) {
                if(name.getText().equalsIgnoreCase(TableViewController.playerArrayList.get(i).getName())){
                    System.out.println("Gotcha");
                    seller.add(TableViewController.playerArrayList.get(i));
                    deliveryObject.setSellList(seller);
                    //deliveryObject.setPlayerArrayList();

                    TableViewController.playerArrayList.remove(i);



                    System.out.println("Size of sellList " + seller.size());
                    //main.getNetworkUtil().write(seller);
                    main.getNetworkUtil().write(deliveryObject);
                    seller.clear();

                    System.out.println("Size of sellList " + seller.size());
                    //main.getNetworkUtil().reseto();
                    //Thread.sleep(100);
                    //System.out.println("Size is " + Server.sellList.size());
                    //sellList = (ArrayList<Player>) main.getNetworkUtil().read();
                }
            }

//            for (int i = 0; i < Server.getSellList().size(); i++) {
//                System.out.println("HEre it is " + Server.getSellList().get(i).getName());
//            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/optionSelect/menuOptions.fxml"));
            try {
                root = loader.load();
                //Person person = loader.getController();
                //personViewController.showData(fName,emaill,fName);

                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }

    }



}
