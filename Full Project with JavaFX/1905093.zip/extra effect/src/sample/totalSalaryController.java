package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import mainFunctions.Player;

import java.util.ArrayList;

public class totalSalaryController {

    @FXML
    private Label salary;
    @FXML
    private Button show;
    private static ArrayList<Player> playerArrayList;

    public static ArrayList<Player> getPlayerArrayList() {
        return playerArrayList;
    }

    public static void setPlayerArrayList(ArrayList<Player> playerArrayList) {
        totalSalaryController.playerArrayList = playerArrayList;
    }

    public void showAllSalary(){

        double sum =0;
        for (int i = 0; i < playerArrayList.size(); i++) {
            sum+= playerArrayList.get(i).getSalary();
        }

        salary.setText(String.valueOf(sum));
    }
}
