package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import mainFunctions.Player;
import mainFunctions.UserInterface;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class countryWisePlayerController {

    private GridPane gridPane;
    private Label label1,label2;
    @FXML
    private Label c1,c2,c3,c4,c5;
    private Label[] l = new Label[5];

    @FXML
    private Button b;

    private String[] str = new String[5];
    private Integer[] in = new Integer[5];

    private static ArrayList<Player> playerArrayList;

    public static ArrayList<Player> getPlayerArrayList() {
        return playerArrayList;
    }

    public static void setPlayerArrayList(ArrayList<Player> playerArrayList) {
        countryWisePlayerController.playerArrayList = playerArrayList;
    }

    public void doit(){
        for (int i = 0; i < playerArrayList.size(); i++) {
            str[i] = playerArrayList.get(i).getCountry().getCountryName();
        }

        str = new HashSet<String>(Arrays.asList(str)).toArray(new String[0]);

        UserInterface u = new UserInterface();

        for (int i = 0; i < str.length; i++) {
           in[i] =  u.CountryWisePlayerCount(str[i],playerArrayList);
        }


            if(str.length==1){
                c1.setText(str[0]+ " : "+ in[0] );
            }
            if(str.length==2){
                c1.setText(str[0]+ " : "+ in[0] );
                c2.setText(str[1] + " : "+ in[1]);
            }
            if(str.length==3){
                c1.setText(str[0]+ " : "+ in[0] );
                c2.setText(str[1] + " : "+ in[1]);
                c3.setText(str[2] + " : "+ in[2]);
            }
            if(str.length==4){
                c1.setText(str[0]+ " : "+ in[0] );
                c2.setText(str[1] + " : "+ in[1]);
                c3.setText(str[2] + " : "+ in[2]);
                c4.setText(str[3] + " : "+ in[3]);
            }
            if(str.length==5){
                c1.setText(str[0]+ " : "+ in[0] );
                c2.setText(str[1] + " : "+ in[1]);
                c3.setText(str[2] + " : "+ in[2]);
                c4.setText(str[3] + " : "+ in[3]);
                c5.setText(str[4] + " : " + in[4]);
            }



    }
}
