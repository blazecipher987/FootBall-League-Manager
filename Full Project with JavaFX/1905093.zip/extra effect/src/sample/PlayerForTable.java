package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import mainFunctions.Club;
import mainFunctions.Country;
import mainFunctions.Player;


import java.io.IOException;
import java.util.ArrayList;

public class PlayerForTable extends Player {

    private Button button;
    private String countrys;
    private String clebs;
    private int index;


    PlayerForTable(){

        this.fname = new SimpleStringProperty(name);
        this.fcountry = new SimpleStringProperty(country.getCountryName());
        this.fage = new SimpleStringProperty(Integer.toString(age));
        this.fheight = new SimpleStringProperty(Double.toString(height));
        this.fclub = new SimpleStringProperty(clubs.getClubName());
        this.fposition = new SimpleStringProperty(position);
        this.fnumber = new SimpleStringProperty(Integer.toString(number));
        this.fsalary = new SimpleStringProperty(Double.toString(salary));

        this.button = new Button("Click");
                button.setOnAction( e -> {
                    //System.out.println(getFirstName() + " " + getLastName() + " " + getEmail());

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("personalView.fxml"));
                    try {
                        root = loader.load();
                        personViewController personViewController = loader.getController();
                        System.out.println(country.getCountryName() + clubs.getClubName());
                        personViewController.showData(name,country.getCountryName(),age,height,clubs.getClubName(),position,salary,price);

                        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }

                }
        );


    }

    PlayerForTable(String name, String country, int age, double height, String clubs, String position, int number, double salary){

        this.name = name;
        // this.country.s = country;
        this.age = age;
        this.height = height;
        //this.clubs = clubs;
        this.position = position;
        this.number = number;
        this.salary = salary;
        this.countrys = country;
        this.clebs = clubs;

        this.fname = new SimpleStringProperty(name);
        this.fcountry = new SimpleStringProperty(country);
        this.fage = new SimpleStringProperty(Integer.toString(age));
        this.fheight = new SimpleStringProperty(Double.toString(height));
        this.fclub = new SimpleStringProperty(clubs);
        this.fposition = new SimpleStringProperty(position);
        this.fnumber = new SimpleStringProperty(Integer.toString(number));
        this.fsalary = new SimpleStringProperty(Double.toString(salary));

        this.button = new Button("Click");
        button.setOnAction( e -> {
                    //System.out.println(getFirstName() + " " + getLastName() + " " + getEmail());

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("personalView.fxml"));
                    try {
                        root = loader.load();
                        personViewController personViewController = loader.getController();
                        System.out.println(country+ clubs);
                        personViewController.showData(name,country,age,height,clubs,position,salary,price);

                        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }

                }
        );
    }

    public Button getButton() {
        return button;
    }

    public void setButton(Button button) {
        this.button = button;
    }

    public String getCountrys() {
        return countrys;
    }

    public void setCountrys(String countrys) {
        this.countrys = countrys;
    }

    public String getClebs() {
        return clebs;
    }

    public void setClebs(String clebs) {
        this.clebs = clebs;
    }
}
