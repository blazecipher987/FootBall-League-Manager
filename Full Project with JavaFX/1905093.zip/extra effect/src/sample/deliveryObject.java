package sample;

import mainFunctions.Player;

import java.io.Serializable;
import java.util.ArrayList;

public class deliveryObject implements Serializable {

    private ArrayList<Player> playerArrayList;
    private ArrayList<Player> sellList;

    public ArrayList<Player> getPlayerArrayList() {
        return playerArrayList;
    }

    public void setPlayerArrayList(ArrayList<Player> playerArrayList) {
        this.playerArrayList = playerArrayList;
    }

    public ArrayList<Player> getSellList() {
        return sellList;
    }

    public void setSellList(ArrayList<Player> sellList) {
        this.sellList = sellList;
    }
}
