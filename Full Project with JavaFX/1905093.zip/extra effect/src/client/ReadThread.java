package client;

import sample.*;
import mainFunctions.*;
import javafx.application.Platform;
import mainFunctions.Main;
import sample.TableViewController;
import util.LoginDTO;

import java.io.IOException;
import java.util.ArrayList;

public class ReadThread implements Runnable {
    private final Thread thr;
    private final Main main;

    public ReadThread(Main main) {
        this.main = main;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = main.getNetworkUtil().read();

                System.out.println("Nani?!");
                System.out.println(o.getClass());
                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        System.out.println(loginDTO.getUserName());
                        System.out.println(loginDTO.getPassword());
                        System.out.println(loginDTO.isStatus());
                        // the following is necessary to update JavaFX UI components from user created threads
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                if (loginDTO.isStatus()) {
                                    try {
                                        System.out.println("Soumya############");
                                        main.showHomePage(loginDTO.getUserName(),loginDTO.getPlayerArrayList(),main.getNetworkUtil());
                                        //main.forHome = loginDTO.getPlayerArrayList();
                                       // main.status = true;
                                        System.out.println("Wasif##############");

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    main.showAlert();
                                }

                            }
                        });
                    }
                    if(o instanceof deliveryObject){
                        TableViewController.selling = ((deliveryObject) o).getSellList();
                        //TableViewController.setPlayerArrayList(((deliveryObject) o).getPlayerArrayList());
                    }

                    if (o instanceof ArrayList){
                        TableViewController.selling = (ArrayList<Player>) o;
                        System.out.println("WE ENtered here %%%%%%%%%%%%%%%%%%%%");
                        ArrayList<Player> p = (ArrayList<Player>) o;
                        for (int i = 0; i < p.size(); i++) {
                            p.get(i).getAllPlayerInfo();
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                main.getNetworkUtil().closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}



