package optionSelect;
import client.LoginController;
import javafx.collections.FXCollections;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import mainFunctions.*;
import javafx.event.ActionEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import sample.*;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import sample.TableViewController;
import util.NetworkUtil;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class menuOptionController implements Initializable {

    @FXML
    private Button button1,button2,button3,button4,button5,button6,button7,button8,button9,sell,logOut;
    @FXML
    private ChoiceBox<String> choiceBox;

    private String[] str = {"Player Name", "By Country"};

    static ObservableList<PlayerForTable> x;
    static ArrayList<Player> pp;
    static ArrayList<PlayerForTable> ppp;
    private NetworkUtil networkUtil;

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    private static int option;
    private static Stage stage;
    @FXML
    private BorderPane pane;
    private Main main;




    @FXML
    private void handleButton1Action(ActionEvent event) throws IOException {
        {

        }

        if(event.getSource()==button1){
            System.out.println("ss");
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(1);
            tableViewController.setNetworkUtil(networkUtil);
        }
//        if(choiceBox.getValue()==str[0]){
//            System.out.println("ss");
//            sceneLoader object = new sceneLoader();
//            Pane view = object.getPane("/sample/tableview");
//            pane.setCenter(view);
//            TableViewController controller = new TableViewController();
//            //controller.setData(x);
//            controller.setPlayerArrayList(pp);
//            TableViewController tableViewController = new TableViewController();
//            tableViewController.setChoice(1);
//            tableViewController.setNetworkUtil(networkUtil);
//        }


        if(event.getSource()==button2){
            System.out.println("ss");
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(2);
        }
        if(event.getSource()==button3){
            System.out.println("ss");
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(3);
            tableViewController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button4){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(4);
            tableViewController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button5){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/countryWisePlayer");
            pane.setCenter(view);
            countryWisePlayerController controller = new countryWisePlayerController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            //TableViewController tableViewController = new TableViewController();
            //countryWisePlayerController.setChoice(10);
            //countryWisePlayerController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button6){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(5);
            tableViewController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button7){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(6);
            tableViewController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button8){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(7);
            tableViewController.setNetworkUtil(networkUtil);
        }
        if(event.getSource()==button9){
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/totalSalary");
            pane.setCenter(view);
            totalSalaryController controller = new totalSalaryController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            //TableViewController tableViewController = new TableViewController();
            //totalSalaryController.setChoice(7);
            //totalSalaryController.setNetworkUtil(networkUtil);
        }

        if(event.getSource()==sell){
            System.out.println("ss");
            sceneLoader object = new sceneLoader();
            Pane view = object.getPane("/sample/tableview");
            pane.setCenter(view);
            TableViewController controller = new TableViewController();
            //controller.setData(x);
            controller.setPlayerArrayList(pp);
            TableViewController tableViewController = new TableViewController();
            tableViewController.setChoice(20);
        }

        if(event.getSource()==logOut){

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/client/login.fxml"));
            Parent root = loader.load();

            // Loading the controller
            LoginController controller = loader.getController();
            controller.setMain(main);
            //TableViewController.setMain(this);

            // Set the primary stage
            stage.setTitle("Login");
            stage.setScene(new Scene(root, 850, 500));
            stage.show();
        }


    }


    public void LoadTable() throws IOException {
        FXMLLoader loader = new FXMLLoader();
//        loader.setLocation(getClass().getResource("/sample/tableview.fxml"));
//        Parent root = loader.load();
        TableViewController controller = loader.getController();

        for (int i = 0; i < pp.size(); i++) {
            ppp.add((PlayerForTable) pp.get(i));
        }

        x = FXCollections.observableArrayList(ppp);
        controller.load(x);
        //primaryStage.setTitle("Table View");
//        stage.setScene(new Scene(root, 700, 400));
//        stage.show();
    }

//    void buttonPress(ActionEvent event) throws IOException {
//        if(event.getSource()=="button1"){
//            LoadTable();
//
//
//        }
//    }

    public void setpp(ArrayList<Player> ppp , Stage stage) {
        pp= ppp;
        this.stage = stage;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


    }
}
