package optionSelect;


import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import mainFunctions.Main;

import java.io.IOException;
import java.net.URL;


public class sceneLoader {

    private Pane view;

    public Pane getPane(String fileName) throws IOException {

        {
            URL fileURL = Main.class.getResource(fileName +".fxml");
            System.out.println(fileURL);

            view = new FXMLLoader().load(fileURL);


            if(fileURL==null){
                throw new java.io.FileNotFoundException("Not Found");
            }

        }
//        catch (Exception e){
//            //System.out.println(e);
//        }


        return view;
    }
}
