import java.util.ArrayList;

public class Country {
    private String countryName;
    private int countryPlayerCount;
    private ArrayList<Player> playerList;

    Country(){
        playerList = new ArrayList<>();
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public int getCountryPlayerCount() {
        return countryPlayerCount;
    }

    public void setCountryPlayerCount(int countryPlayerCount) {
        this.countryPlayerCount = countryPlayerCount;
    }

    public ArrayList<Player> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(ArrayList<Player> playerList) {
        this.playerList = playerList;
    }

    public void addPlayerToCountry(Player p){
        Player x = new Player();
        x = p;
        playerList.add(x);
        p.setCountry(this);

        //System.out.println(p.getName());
        //System.out.println("IYAAA" +playerList.get(playerList.size()-1).getCountry());

    }


}
