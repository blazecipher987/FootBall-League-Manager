import java.util.ArrayList;
import java.util.List;

public class Player {

    private String name;
    private int age;
    private double height;
    private Club clubs;
    private String position;
    private int number;
    private double salary;
    private Country country;
    private int clubDecided;

    Player(){
        clubDecided= 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public Club getClubs() {
        return clubs;
    }

    public void setClubs(Club clubs) {
        this.clubs = clubs;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getClubDecided() {
        return clubDecided;
    }

    public void setClubDecided(int clubDecided) {
        this.clubDecided = clubDecided;
    }
    public boolean notAddedToClub(){
        return false;
    }

    public void addToClub(ArrayList<Club> c,String s){

       // System.out.println("Executing adding to club, string " + s);
        int notRepeat = 1;
        int index = 0;

        for (int i = 0; i < c.size(); i++) {
            //System.out.println("Gif");
            if(c.get(i).getClubName().equals(s) == true){
                //System.out.println("Got a match");
                notRepeat = 0;
                index =i;
                break;
            }
        }

        if(notRepeat==0){
            if(c.get(index).getCurrentPlayerCount() <7){
                clubDecided=1;
                //System.out.println("same as club " + index);
                c.get(index).addPlayer(this);
                c.get(index).setCurrentPlayerCount(c.get(index).getCurrentPlayerCount()+1);
                this.setClubs(c.get(index));
            }
            else{
                //System.out.println("Current Club is already full,select another club");
                clubDecided=0;
            }
        }

        else{
            clubDecided=1;
            //System.out.println("Adding to new club");
            Club x = new Club();
            x.setClubName(s);
            x.setCurrentPlayerCount(x.getCurrentPlayerCount()+ 1);
            //System.out.println(x.getCurrentPlayerCount());
            c.add(x);
            c.get(c.size()-1).addPlayer(this);

            for (int i = 0; i < c.size(); i++) {
                if(s.equalsIgnoreCase(c.get(i).getClubName())==true){
                    this.setClubs(c.get(i));
                    break;
                }
            }

        }

    }
    public void addToCountry(ArrayList<Country> c , String s){
        int notRepeat = 1;
        int index=0;
        //System.out.println();

        //System.out.println("Current country: " + s);
        for (int i = 0; i < c.size(); i++) {
            if(c.get(i).getCountryName().equals(s) == true){
                //System.out.println("Got a match");
                notRepeat = 0;
                index =i;
                break;
            }
        }

        if(notRepeat==0){
            //System.out.println("same as Country " + c.get(index).getCountryName());
            c.get(index).addPlayerToCountry(this);
            c.get(index).setCountryPlayerCount(c.get(index).getCountryPlayerCount()+1);
            this.setCountry(c.get(index));


        }
        else{
            //System.out.println("First Country for the entry: " + s);
            Country x = new Country();
            x.setCountryName(s);
            x.setCountryPlayerCount(x.getCountryPlayerCount()+1);
            //System.out.println(x.getCountryPlayerCount());
            c.add(x);

            c.get(c.size()-1).addPlayerToCountry(this);
            for (int i = 0; i < c.size(); i++) {
                if(s.equalsIgnoreCase(c.get(i).getCountryName())==true){
                    this.setCountry(c.get(i));
                    break;
                }
            }

        }
    }
    public void getAllPlayerInfo(){
        System.out.println("Player Name: "+ getName());
        System.out.println("Player country: "+ getCountry().getCountryName());
        System.out.println("Player age: " + getAge());
        System.out.println("Player Height: "+ getHeight());
        System.out.println("Player club: " + this.getClubs().getClubName());
        System.out.println("Player position: " + getPosition());
        System.out.println("Player number: "+ getNumber());
        System.out.println("Player Salary: "+getSalary());
        System.out.println();

    }

}
