import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception {

        ArrayList<Club> clubList = new ArrayList<>();
        ArrayList<Country> countryList = new ArrayList<>();
        FileHandling f = new FileHandling();

        ArrayList<Player> playerList = f.readFromFile(clubList, countryList);



        //Testing
//        for (int i = 0; i < clubList.size(); i++) {
//           //clubList.get(i).printAllClubInfo();
//            //clubList.get(i).findMaxSalary();
//            //clubList.get(i).findMaxAge();
//            //clubList.get(i).findMaxHeight();
//        };
        System.out.println();


        UserInterface u = new UserInterface();
        u.MainMenu(playerList,clubList,countryList);

        playerList = u.ReturnList();

        f.writeToFile(playerList);


    }
}
