import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Club {

    private String clubName;
    private int currentPlayerCount;
    private int maxPlayerCount;
    private ArrayList<Player> playerList;
    private double maxSalary;
    private double maxHeight;
    private int maxAge;
    private double yearlySalary;
    private double weaklySalary;

    Club(){
        playerList = new ArrayList<>();
        maxPlayerCount =7;
        maxSalary=0;
        maxAge=0;
        maxHeight=0;
    }


    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public int getCurrentPlayerCount() {
        return currentPlayerCount;
    }

    public void setCurrentPlayerCount(int currentPlayerCount) {
        this.currentPlayerCount = currentPlayerCount;
    }

    public int getMaxPlayerCount() {
        return maxPlayerCount;
    }

    public void setMaxPlayerCount(int maxPlayerCount) {
        this.maxPlayerCount = maxPlayerCount;
    }

    public ArrayList<Player> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(ArrayList<Player> playerList) {
        this.playerList = playerList;
    }

    public double getMaxSalary() {
        double m= FindMaxSalary();
        return m;
    }

    public void setMaxSalary(double maxSalary) {
        this.maxSalary = maxSalary;
    }

    public double getMaxHeight() {
        return maxHeight;
    }

    public void setMaxHeight(double maxHeight) {
        this.maxHeight = maxHeight;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public double getYearlySalary() {
        return yearlySalary;
    }

    public void setYearlySalary(double yearlySalary) {
        this.yearlySalary = yearlySalary;
    }

    public void printAllClubInfo(){
        System.out.println(clubName);
        System.out.println("Player Count: " + currentPlayerCount);
        for (int i = 0; i < playerList.size(); i++) {
            System.out.println(playerList.get(i).getName());
        }
    }

    public void addPlayer(Player p){


        //System.out.println("In");
        Player m = new Player();
        m=p;
        playerList.add(m);

    }

//    public void findMaxSalary(){
//        for (int i = 0; i < playerList.size(); i++) {
//            if(playerList.get(i).getSalary()>getMaxSalary()){
//                setMaxSalary(playerList.get(i).getSalary());
//            }
//        }
//        System.out.println(getMaxSalary());
//    }

    public void findMaxAge(){
        for (int i = 0; i < playerList.size(); i++) {
            if(playerList.get(i).getAge()>getMaxAge()){
                setMaxAge(playerList.get(i).getAge());
            }
        }
        System.out.println(getMaxAge());
    }

    public void findMaxHeight(){
        for(int i=0;i<playerList.size();i++){
            if(playerList.get(i).getHeight()>getMaxHeight()){
                setMaxHeight(playerList.get(i).getHeight());
            }
        };
        System.out.println(getMaxHeight());
    }

    public void FindYearlySalary(){
        for(int i=0;i<playerList.size();i++){
            //System.out.println(playerList.get(i).getSalary());
            weaklySalary+=playerList.get(i).getSalary();
        };

        double x = weaklySalary/7;
        yearlySalary = ((weaklySalary*52) + x);
        setYearlySalary(yearlySalary);

        System.out.println("Yearly Salary: "+ yearlySalary);
    }
    public double FindMaxSalary(){
        double x =0.0;
        for (int i = 0; i < playerList.size(); i++) {
            if(playerList.get(i).getSalary() > x){
                x=playerList.get(i).getSalary();
            }
        }
        return x;
    }
    public void GetMaxAge(){
        //int temp=0;
        for (int i = 0; i < playerList.size(); i++) {
            //System.out.println(playerList.get(i).getAge());
            if(playerList.get(i).getAge()>maxAge){
                maxAge=playerList.get(i).getAge();
            }
        }

        System.out.println("Max age is: " + maxAge);
    }

}
