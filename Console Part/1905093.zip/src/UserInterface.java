import java.time.format.SignStyle;
import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {

    private ArrayList<Player> playerList;
    private ArrayList<Club> clubList;
    private ArrayList<Country> countryList;
    private int clubDecided;

    //Utility functions
    public int ErrorHandling(int min, int max){
        int result;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Please enter a valid input");
            result = sc.nextInt();
        }while(result<min || result>max);

        return result;
    }
    public int CheckIfAllDigits(String text){
        boolean flag;
        String s;
        do{
            flag = true;
            Scanner sc = new Scanner(System.in);
            System.out.print(text);
            s = sc.nextLine();
            for (int i = 0; i < s.length(); i++) {
                if(Character.isDigit(s.charAt(i))!=true){
                    flag=false;
                    System.out.println("Enter a valid input");
                    break;
                }
            }
        }while (flag==false);

        return Integer.parseInt(s);
    }
    public double CheckIfDouble(String text){
        boolean flag=false;
        String s;
        Double x = 0.0;

        while(flag==false){
            try {
                System.out.print(text);
                Scanner sc = new Scanner(System.in);
                String str = sc.next();
                Double doub = Double.parseDouble(str);
                flag=true;
                x = doub;
                if(doub<0){
                    flag=false;
                    System.out.println("Input can't be negative");
                }
            }catch (NumberFormatException ex) {
                System.out.println("Given String is not parsable to double,Enter a valid input");
                flag=false;
            }
        }
        return x;
    }
    public int CheckForNumberRepetition(String s){
        Scanner sc = new Scanner(System.in);
        int number;
        int result=0;
        boolean flag;
                do{
                    System.out.print("Enter Player Number: ");
                    flag=true;
                    number = sc.nextInt();
                    for (int i = 0; i < playerList.size(); i++) {
                        if(s.equalsIgnoreCase(playerList.get(i).getClubs().getClubName())==true){
                            for (int j = 0; j<playerList.size() ; j++) {
                                if(playerList.get(i).getNumber()==number){
                                    System.out.println("Player of this number already exist in this club,try again");
                                    flag=false;
                                    break;
                                }
                            }
                        }
                    }
                } while(flag==false);

                return number;
    }
    public String CheckNamesForRepetition(){
        int flag;
        String name;
        do{
            flag=1;
            System.out.print("Enter the player name: ");
            Scanner x = new Scanner(System.in);
            name = x.nextLine();

            for (int i = 0; i < playerList.size(); i++) {
                if(name.equalsIgnoreCase(playerList.get(i).getName())==true){
                    flag=0;
                    System.out.println("Player of this name already exits,try again");
                    break;
                }
            }
        }while(flag==0);

        return name;
    }

    //Option 1 functions
    public void SearchClubAndCountry(){
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);

        System.out.print("Enter Club Name: ");
        String clubName = sc1.nextLine();
        System.out.print("Enter Country Name: ");
        String countryName = sc2.nextLine();

        int clubFound =1;
        int countryFound=1;
        int found=0;
//            for (int i = 0; i < clubList.size(); i++) {
//                if(clubList.get(i).getClubName().equalsIgnoreCase(clubName)==true){
//
//                    for (int j = 0; j < countryList.size(); j++) {
//                        if(countryList.get(j).getCountryName().equalsIgnoreCase(countryName)==true){
//                            for(int k=0 ; k< clubList.get(j).);
//                        }
//                        else {
//                            System.out.println("Player from this country doesn't exist");
//                        }
//                    }
//                }
//
//                else{
//                    System.out.println("Player from this Club doesn't exist");
//                }
//            }

        for (int i = 0; i < playerList.size(); i++) {
            if(playerList.get(i).getClubs().getClubName().equalsIgnoreCase(clubName) && playerList.get(i).getCountry().getCountryName().equalsIgnoreCase(countryName)==true){
                playerList.get(i).getAllPlayerInfo();
                found =1;
            }
        }
        if(found==0){
            System.out.println("This player doesn't exist in the database");
        }

        MainMenu(playerList,clubList,countryList);
    }
    public void SearchWithPosition(){
        System.out.print("Enter a valid input: ");
        Scanner sc = new Scanner(System.in);
        String position = sc.nextLine();
        int found =0;
        for (int i = 0; i < playerList.size(); i++) {
            if(position.equalsIgnoreCase(playerList.get(i).getPosition())==true){
                //System.out.println(playerList.get(i).getName());
                playerList.get(i).getAllPlayerInfo();
            }
        }

        MainMenu(playerList,clubList,countryList);
    }
    public void SearchWithSalaryRange(){
        Scanner sc1 = new Scanner(System.in);
        System.out.print("Enter the Salary lower bound: ");
        Double lowerBound = sc1.nextDouble();
        System.out.print("Enter the Salary Upper Bound: ");
        Double upperBound = sc1.nextDouble();

        int found = 0 ;
        for (int i = 0; i < playerList.size(); i++) {
            if(playerList.get(i).getSalary()> lowerBound && playerList.get(i).getSalary()<upperBound){
                found=1;
                //System.out.println(playerList.get(i).getName()+" : "+ playerList.get(i).getSalary());
                playerList.get(i).getAllPlayerInfo();
            }
        }

        if(found==0){
            System.out.println("Player between this salary range doesn't exist");
        }

        MainMenu(playerList,clubList,countryList);

    }
    public void CountryWisePlayerCount(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a country name: ");
        String countryName = sc.nextLine();
        int found=0;
        int count=0;
        for(int i=0 ; i< playerList.size();i++){
            if(playerList.get(i).getCountry().getCountryName().equalsIgnoreCase(countryName)==true){
                found=1;
                count++;
            }
        }
        if(found==1){
            System.out.println("PLayer from " +countryName + " : " + count);
        }
        else{
            System.out.println("Players from this Country doesn't exist");
        }
        MainMenu(playerList,clubList,countryList);
    }

    //Option 2 functions
    public void MaxSalaryInClub(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a club name: ");
        String clubName = sc.nextLine() ;
        boolean found= false;
        double maxSalary=0;
        for (int i = 0; i < clubList.size(); i++) {

            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
                maxSalary= clubList.get(i).getMaxSalary();
                System.out.println(maxSalary);
                for (int j = 0; j < playerList.size(); j++) {
                    if(maxSalary==playerList.get(j).getSalary()){
                        playerList.get(j).getAllPlayerInfo();
                    }
                }
                found=true;
                break;
            }
        }
//        if(found){
//            System.out.println("The Max Salary of the club is: " + maxSalary);
//        }
        if(found==false){
            System.out.println("This club doesn't exist");
        }
        MainMenu(playerList,clubList,countryList);
    }
    public void MaxAgeInClub(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a club name: ");
        String clubName = sc.nextLine() ;
        boolean found= false;
        int maxAge=0;
        for (int i = 0; i < clubList.size(); i++) {
            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
                clubList.get(i).GetMaxAge();
                found=true;
                break;
            }
        }
        if(found==false){
            System.out.println("This club doesn't exist");
        }
        MainMenu(playerList,clubList,countryList);
    }
    public void MaxHeightInClub(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a club name: ");
        String clubName = sc.nextLine() ;
        boolean found= false;
        double maxHeight=0;
        for (int i = 0; i < clubList.size(); i++) {
            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
                maxHeight= clubList.get(i).getMaxHeight();
                found=true;
                break;
            }
        }
        if(found){
            System.out.println("The Max Salary of the club is: " + maxHeight);
        }
        else{
            System.out.println("This club doesn't exist");
        }
        MainMenu(playerList,clubList,countryList);
    }
    public void YearlySalaryOfClub(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a club name: ");
        String clubName = sc.nextLine() ;
        boolean found= false;
        double yearlySalary=0;
        for (int i = 0; i < clubList.size(); i++) {
            if(clubName.equalsIgnoreCase(clubList.get(i).getClubName())==true){
                clubList.get(i).FindYearlySalary();
                yearlySalary= clubList.get(i).getMaxSalary();

                found=true;
                break;
            }
        }

        if(found==false){
            System.out.println("This club doesn't exist");
        }
        MainMenu(playerList,clubList,countryList);
    }


    public void MainMenu(ArrayList<Player> playerList, ArrayList<Club> clubList, ArrayList<Country> countryList){

        this.playerList = new ArrayList<>(playerList);
        this.clubList = new ArrayList<>(clubList);
        this.countryList = new ArrayList<>(countryList);


        System.out.println("Main Menu:");
        System.out.println("(1) Search Players");
        System.out.println("(2) Search Clubs");
        System.out.println("(3) Add Player");
        System.out.println("(4) Exit System");
        System.out.println("(5) Extra Options");

        Scanner sc1 = new Scanner(System.in);
        int option1 = sc1.nextInt();

        if(option1==1){
            SearchPlayers();
        }
        if(option1==2){
            SearchClubs();
        }
        if(option1==3){
            AddPlayers();
        }
        if(option1==4) {
            System.out.println("Data has been saved to file");
        }
        if(option1==5){
            ExtraOptions();
        }

    }
    public void SearchPlayers(){
        System.out.println("(1) By Player Name\n" +
                "(2) By Club and Country\n" +
                "(3) By Position\n" +
                "(4) By Salary Range\n" +
                "(5) Country-wise player count\n" +
                "(6) Back to Main Menu");

        int option2 = ErrorHandling(1,6);
        if(option2==1){
            Scanner sc = new Scanner(System.in);
            String name = sc.nextLine();
            int searchSuccessful=0;
            for (int i = 0; i < playerList.size(); i++) {
                if(name.equalsIgnoreCase(playerList.get(i).getName())==true){
                    playerList.get(i).getAllPlayerInfo();
                    searchSuccessful=1;
                }
            }
            if(searchSuccessful==0){//Error Handling
                System.out.println("This Player doesn't exist in the database");
            }
            MainMenu(playerList,clubList,countryList);
        }
        if(option2==2){
            SearchClubAndCountry();
        }
        if(option2==3){
            SearchWithPosition();
        }
        if(option2==4){
            SearchWithSalaryRange();
        }
        if(option2==5){
            CountryWisePlayerCount();
        }
        if(option2==6){
            MainMenu(playerList,clubList,countryList);
        }
    }
    public void SearchClubs(){
        System.out.println("Club Searching Options:\n" +
                "(1) Player(s) with the maximum salary of a club\n" +
                "(2) Player(s) with the maximum age of a club\n" +
                "(3) Player(s) with the maximum height of a club\n" +
                "(4) Total yearly salary of a club\n" +
                "(5) Back to Main Menu");

        int option2 = ErrorHandling(1,5);

        if(option2==1){
            MaxSalaryInClub();
        }
        if(option2==2){
            MaxAgeInClub();
        }
        if(option2==3){
            MaxHeightInClub();
        }
        if(option2==4){
            YearlySalaryOfClub();
        }
        if(option2==5){
            MainMenu(playerList,clubList,countryList);
        }
    }
    public void AddPlayers(){

        Player p = new Player();
        int flag;
        Scanner sc = new Scanner(System.in);

        //Name
        String name = CheckNamesForRepetition();
        p.setName(name);

        //Country
        System.out.print("Enter Country: ");
        String country = sc.nextLine();
        p.addToCountry(countryList,country);

        //Age
        int age = CheckIfAllDigits("Enter Age: ");
        p.setAge(age);

        //Height
        double h = CheckIfDouble("Enter Height: ");
        p.setHeight(h);

        //Club
        String club;
        do{
            System.out.print("Enter Club: ");
             club = sc.nextLine();
            p.addToClub(clubList, club);
        }while(p.getClubDecided()==0);

        //Position
        System.out.print("Enter Position: ");
        String position = sc.nextLine();
        p.setPosition(position);

        //Number
        int num =  CheckForNumberRepetition(club);
        p.setNumber(num);

        //Weekly Salary
        double salary = CheckIfDouble("Enter Salary: ");
        p.setSalary(salary);

        playerList.add(p);

        MainMenu(playerList,clubList,countryList);
    }
    public void ExtraOptions(){
        System.out.println("View all player info in current database");
        System.out.println("(1) Yes");
        System.out.println("(2) No (Return to Main Menu)");

        int x = ErrorHandling(1,2);
        if(x==1){
            for (int i = 0; i < playerList.size(); i++) {
                playerList.get(i).getAllPlayerInfo();
            }
            MainMenu(playerList,clubList,countryList);
        }
        else {
            MainMenu(playerList,clubList,countryList);
        }
    }

    public ArrayList<Player> ReturnList(){
        return playerList;
    }


}
